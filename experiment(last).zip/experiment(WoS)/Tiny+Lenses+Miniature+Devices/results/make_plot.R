
install.packages('scales')
install.packages("readxl")


library(scales)
library(readxl)

observed_data <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(WoS)/Tiny+Lenses+Miniature+Devices/results/lstm_input_R.xlsx", col_name = TRUE)
predicted_data <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(WoS)/Tiny+Lenses+Miniature+Devices/results/lstm_out_result_edit_R.xlsx", col_name = TRUE)

plot(observed_data$year, observed_data$patent_num, xlim=range(1990, 2025), type = "l", lty = 1, col = "blue", xlab = "year", ylab = "paper_num", main = "Prediction of number of papers")

lines(predicted_data$year, predicted_data$patent_num, type = "l", lty = 1, col = "red")

legend(x = 1990, y = 3, legend = c("observed paper_num", "predicted paper_num"), col = c("blue", "red"), lty = c(1,1), box.lty=0)


