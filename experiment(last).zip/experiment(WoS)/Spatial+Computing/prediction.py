# -*- coding: utf-8 -*-
"""
Created on Wed Feb  2 05:07:05 2022

@author: shnoh
"""


import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt

data = np.loadtxt("E:/AI_Exercise/8-th paper/experiment(last)/experiment(WoS)/Spatial+Computing/test1.txt", delimiter="\t")
#dataset = np.nan_to_num(np.asarray(data, dtype=np.int))
#input_tensor = torch.from_numpy(dataset).float()


#print(input_tensor)
#print(input_tensor.size(1))
sequence_length=10
latency=3


class CustomDataset(Dataset):
    def __init__(self, data, sequence_length=10, latency=3):
        
        super(CustomDataset, self).__init__()        
        dataset = np.nan_to_num(np.asarray(data, dtype=np.int))
        self.sqlen = sequence_length
        
        self.input_tensor = torch.from_numpy(dataset).float()   
        

        self.inp, self.label = [], []
        for i in range(self.input_tensor.size(1)-sequence_length-latency):
            self.inp.append(self.input_tensor[:,i:i+sequence_length])
            self.label.append(self.input_tensor[:,i+sequence_length:i+sequence_length+latency])
            
        self.test_inp1 = self.input_tensor[:, self.input_tensor.size(1)-sequence_length-3:self.input_tensor.size(1)-3]
        self.test_inp2 = self.input_tensor[:, self.input_tensor.size(1)-sequence_length-2:self.input_tensor.size(1)-2]        
        self.test_inp3 = self.input_tensor[:, self.input_tensor.size(1)-sequence_length-1:self.input_tensor.size(1)-1]
        self.test_inp4 = self.input_tensor[:, self.input_tensor.size(1)-sequence_length:self.input_tensor.size(1)]
    
    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        # sqlen 만큼을 입력 데이터로 반환
        return self.inp[idx], self.label[idx][1], self.test_inp1, self.test_inp2, self.test_inp3, self.test_inp4



#inp, label = [], []
#for i in range(input_tensor.size(1)-sequence_length-latency):
#    inp.append(input_tensor[:,i:i+sequence_length])
#    label.append(input_tensor[:,i+sequence_length:i+sequence_length+latency])

#print(inp)
#print(label)
    
# experiment configuration
epochs = 200
batch_size = 1
# model configuration
hidden_size = 100

dataset = CustomDataset(data,sequence_length=sequence_length, latency=latency)
    
dataloader = DataLoader(dataset, batch_size=batch_size, num_workers=0,
                            pin_memory=True,drop_last=True)

# Define the model
class LSTM(nn.Module):
    def __init__(self, input_size, hidden_size, device):
        super(LSTM, self).__init__()
        self.hidden_size = hidden_size
        self.device = device

        self.inp = nn.Linear(input_size, hidden_size).to(device)
        self.LSTMCell_1 = nn.LSTMCell(hidden_size, hidden_size, 2).to(device)
#        self.LSTMCell_2 = nn.LSTMCell(hidden_size, hidden_size).to(device)
        self.dropout = nn.Dropout(p=0.05).to(device)
        self.fc = nn.Linear(hidden_size, 3).to(device)

    def step(self, inp, hidden=None):
        
        # dropout은 현재 time step에만 적용        
        hidden1 = self.LSTMCell_1(self.dropout(inp))        
#        hidden2 = self.LSTMCell_2        

        return hidden1

    def forward(self, inputs, hidden=None, steps=0):
        if steps == 0:
            steps = inputs.size(1)

        inputs = self.inp(inputs)

        hidden = None
        for i in range(steps):
            hidden = self.step(inputs[:,i], hidden)
            
           
        hidden[0].mean().backward(retain_graph=True)
        
        out = self.dropout(self.dropout(hidden[0]))
        out = self.fc(out)
        
        return out
    
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

lstm = LSTM(input_size=10,
                hidden_size=hidden_size,
                device=device)

criterion = nn.MSELoss()
optimizer = torch.optim.SGD(lstm.parameters(), lr=1e-3)

  
results_out, results_loss = [], []
for e in range(epochs):
    loss_avg = 0
    correct = 0
    difference = 0    
    
    for i, batch in enumerate(dataloader, 1):
            optimizer.zero_grad()        
            inp, label, test_inp1, test_inp2, test_inp3, test_inp4 = batch
#            print(inp)
            #print(label)
            inp, label, test_inp1, test_inp2, test_inp3, test_inp4 = inp.to(device), label.to(device), test_inp1.to(device), test_inp2.to(device),test_inp3.to(device), test_inp4.to(device)
            out = lstm(inp)
            #print(out)
            results_out.append((e, i, out))

            loss = criterion(out, label)
            loss.backward()
            loss_avg += loss.item()
            
            difference += (abs(out-label)*(100/23)).mean().item()
            
            optimizer.step()
            
    test_out1 = lstm(test_inp1)
    test_out2 = lstm(test_inp2)
    test_out3 = lstm(test_inp3)
    test_out4 = lstm(test_inp4)
#    results_out.append((e, i, test_out1, test_out2, test_out3))    
    
    correct = (100-difference/i)
    print("epoch: {} | iter: {} | loss: {} | acc: {} | out: {}".format(e, i, loss_avg/i, correct, out))
    
        
    results_loss.append((e, loss_avg/i))
    
results_out.append((e, i+1, test_out1))
results_out.append((e, i+2, test_out2))
results_out.append((e, i+3, test_out3))
results_out.append((e, i+4, test_out4))
## compute test_out
    

    
with open('E:/AI_Exercise/8-th paper/experiment(last)/experiment(WoS)/Spatial+Computing/results/lstm_loss_result.csv', 'w', encoding='utf8') as f:
    f.write('epoch,loss')
    for tup in results_loss:
        f.write("{},{}\n".format(*tup))
        
with open('E:/AI_Exercise/8-th paper/experiment(last)/experiment(WoS)/Spatial+Computing/results/lstm_out_result.csv', 'w', encoding='utf8') as g:
    g.write('epoch, iteration,out')
    for tup in results_out:
        g.write("{},{},{}\n".format(*tup))    
    
    

    
    
    
    
    
    
    
    
    