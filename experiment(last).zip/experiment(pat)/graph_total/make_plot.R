
install.packages('scales')
install.packages("readxl")


library(scales)
library(readxl)


predicted_data_1 <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(pat)/graph_total/lstm_out_result_edit_R(1).xlsx", col_name = TRUE)
predicted_data_2 <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(pat)/graph_total/lstm_out_result_edit_R(2).xlsx", col_name = TRUE)
predicted_data_3 <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(pat)/graph_total/lstm_out_result_edit_R(3).xlsx", col_name = TRUE)
predicted_data_4 <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(pat)/graph_total/lstm_out_result_edit_R(4).xlsx", col_name = TRUE)
predicted_data_5 <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(pat)/graph_total/lstm_out_result_edit_R(5).xlsx", col_name = TRUE)
predicted_data_6 <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(pat)/graph_total/lstm_out_result_edit_R(6).xlsx", col_name = TRUE)
predicted_data_7 <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(pat)/graph_total/lstm_out_result_edit_R(7).xlsx", col_name = TRUE)
predicted_data_8 <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(pat)/graph_total/lstm_out_result_edit_R(8).xlsx", col_name = TRUE)
predicted_data_9 <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(pat)/graph_total/lstm_out_result_edit_R(9).xlsx", col_name = TRUE)
predicted_data_10 <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(pat)/graph_total/lstm_out_result_edit_R(10).xlsx", col_name = TRUE)


plot(predicted_data_1$year, predicted_data_1$patent_num, xlim=range(1990, 2025), ylim=range(-2,50), type = "l", lty = 1, lwd=1.5, col = '#ff6600', xlab = "year", ylab = "patent_num", main = "Prediction of number of patents")

lines(predicted_data_2$year, predicted_data_2$patent_num, type = "l", lty = 1, lwd=1.5, col = '#002955')
lines(predicted_data_3$year, predicted_data_3$patent_num, type = "l", lty = 1, lwd=1.5, col = '#074ca1')
lines(predicted_data_4$year, predicted_data_4$patent_num, type = "l", lty = 1, lwd=1.5, col = '#7c0022')
lines(predicted_data_5$year, predicted_data_5$patent_num, type = "l", lty = 1, lwd=1.5, col = "blue")
lines(predicted_data_6$year, predicted_data_6$patent_num, type = "l", lty = 1, lwd=1.5, col = "violet")
lines(predicted_data_7$year, predicted_data_7$patent_num, type = "l", lty = 1, lwd=1.5, col = '#000000')
lines(predicted_data_8$year, predicted_data_8$patent_num, type = "l", lty = 1, lwd=1.5, col = "yellow")
lines(predicted_data_9$year, predicted_data_9$patent_num, type = "l", lty = 1, lwd=1.5, col = '#315288')
lines(predicted_data_10$year, predicted_data_10$patent_num, type = "l", lty = 1, lwd=1.5, col = '#ff0000')

#legend(x = 1990, y = 60, legend = c("D", "V", "S", "Q", "P", "PE", "E", "W", "E", "G"), col = c("darkblue","red","violet", "yellow", "brown", "khaki1", "pink", "black", "orange", "violetred1"), lty = c(1,1,1,1,1,1,1,1,1,1), box.lty=0)


legend(x = 1990, y = 50, legend = c("Augmented Reality", "Plasmonic Materials", "Virtual Patients", "Spatial Computing", "Quantum Sensing", "Social Robots", "Personalised Medicine", "Electroceuticals", "Green Hydrogen", "Digital Medicine"), col = c('#ff6600','#002955','#074ca1','#7c0022',"blue","violet",'#000000',"yellow",'#315288','#ff0000'), lty = c(1,1,1,1,1,1,1,1,1,1), lwd=c(1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5),box.lty=0)


