
install.packages('tm')
install.packages('stringr')
install.packages('readxl')
install.packages('dplyr')
install.packages('janeaustenr')
install.packages('tidytext')
install.packages("openxlsx")

library(stringr)
library(tm)
library(readxl)
library(dplyr)
library(janeaustenr)
library(tidytext)
library(openxlsx)

abstract_set <- read_excel("E:/AI_Exercise/8-th paper/experiment/Electric+Aviation/Electric+Aviation.xlsx",
                           sheet = "Sheet1", range = "A1:B8")
#head(abstract_set)




abstract.df <- data.frame(doc_id = row.names(abstract_set), text = abstract_set$text)

abstract.corpus <- Corpus(DataframeSource(data.frame(abstract.df)))

abstract.corpus <- tm_map(abstract.corpus, content_transformer(removePunctuation))
abstract.corpus <- tm_map(abstract.corpus, content_transformer(tolower))
#abstract.corpus <- tm_map(abstract.corpus, content_transformer(PlainTextDocument))
abstract.corpus <- tm_map(abstract.corpus, content_transformer(function(x) removeWords(x, stopwords("english"))))

tdm <- TermDocumentMatrix(abstract.corpus)

m <- as.matrix(tdm)
v <- rowSums(m)
d <- data.frame(word = names(v), freq = v) ## TF

m1 <- matrix(0,ncol=7,nrow=175,byrow = T)

for (i in 1:175){
  for (j in 1:7){
    if (m[i, j]>0){
      m1[i, j]=1
    }
  }
}

head(m1)

v1 <- rowSums(m1)
d1 <- data.frame(word = names(v), freq = v1) ## DF

idf <- log(7/(1+d1$freq))
tf_idf <- d$freq * idf

result <- data.frame(word = names(v), TF = d$freq, DF = d1$freq, TF_IDF = tf_idf)
  
 
write.xlsx(result, sheetName="sheet1", file="word_freq.xlsx")






