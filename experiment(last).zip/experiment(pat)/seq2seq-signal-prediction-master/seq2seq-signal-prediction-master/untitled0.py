# -*- coding: utf-8 -*-
"""
Created on Wed Feb  9 11:06:37 2022

@author: shnoh
"""

import import_ipynb
import seq2seq.ipynb