
install.packages('scales')
install.packages("readxl")


library(scales)
library(readxl)

observed_data <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(pat)/Plasmonic+materials/results/lstm_input_R.xlsx", col_name = TRUE)
predicted_data <- read_excel("E:/AI_Exercise/8-th paper/experiment(last)/experiment(pat)/Plasmonic+materials/results/lstm_out_result_edit_R.xlsx", col_name = TRUE)

plot(observed_data$year, observed_data$patent_num, xlim=range(1990, 2025), type = "l", lty = 1, lwd=2, col = "blue", xlab = "year", ylab = "patent_num", main = "Prediction of number of patents (Plasmonic materials)")

lines(predicted_data$year, predicted_data$patent_num, type = "l", lty = 1, lwd=2, col = "red")

legend(x = 1990, y = 60, legend = c("observed patent_num", "predicted patent_num"), col = c("blue", "red"), lty = c(1,1), lwd=2, box.lty=0)


